# Knowledge Nexus: SDG Gamified Web Platform

## Overview
"Knowledge Nexus" is a fully responsive, interactive educational web application designed to educate children (ages 8–14) about the 17 UN Sustainable Development Goals (SDGs) through staged progression, gamification, and scenario-based character learning.

## How to Run Locally
1.  **Clone the repository (or unzip the provided folder):**
    ```bash
    git clone <repository_url>
    # or unzip knowledge_nexus.zip
    ```
2.  **Navigate to the project directory:**
    ```bash
    cd knowledge_nexus
    ```
3.  **Open `index.html` in your web browser.** You can simply double-click the file or use a local web server (e.g., Python's `http.server`):
    ```bash
    python3 -m http.server
    ```
    Then, open your browser and go to `http://localhost:8000`.

## How to Deploy on GitHub Pages
1.  **Create a new GitHub repository** (if you haven't already).
2.  **Push your project to the repository.**
3.  **Go to your repository settings on GitHub.**
4.  **Navigate to the "Pages" section.**
5.  **Under "Build and deployment", select "Deploy from a branch" and choose your main branch (e.g., `main` or `master`) and the `/ (root)` folder.**
6.  **Save your changes.** Your site will be deployed to `https://<your-username>.github.io/<your-repository-name>/` within a few minutes.

## Credits
*   **Character Image Placeholders:** Images are currently placeholders from `via.placeholder.com`. For a production version, you would replace these with actual character illustrations. Ensure you have the necessary licenses or permissions for any images used.


