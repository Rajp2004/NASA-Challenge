
document.addEventListener('DOMContentLoaded', () => {
    // Quiz Data (Example for Quality Education - Level 4)
    const quizData = [
        {
            question: "Daniel is creating flexible lesson plans. What's the first step to identify learning styles?",
            options: [
                "Observe student engagement",
                "Ask students directly",
                "Review past performance",
                "Identify learning styles"
            ],
            answer: "Identify learning styles"
        },
        {
            question: "For long-term support, what should Daniel do?",
            options: [
                "Stick to one method",
                "Assess and adapt methods",
                "Ignore feedback",
                "Use only visual aids"
            ],
            answer: "Assess and adapt methods"
        },
        {
            question: "Leila is bridging the tech divide. What should she focus on first?",
            options: [
                "Teach advanced coding",
                "Teach basic digital tools",
                "Buy new computers",
                "Ignore tech skills"
            ],
            answer: "Teach basic digital tools"
        },
        {
            question: "For long-term impact, what should Leila do?",
            options: [
                "Work alone",
                "Partner with orgs for devices",
                "Stop teaching",
                "Only teach adults"
            ],
            answer: "Partner with orgs for devices"
        },
        {
            question: "Suresh is creating a teacher collaboration platform. What's the first step?",
            options: [
                "Create a social media group",
                "Create resource-sharing platform",
                "Organize a party",
                "Do nothing"
            ],
            answer: "Create resource-sharing platform"
        },
        {
            question: "To ensure sustainability, what should Suresh do?",
            options: [
                "Organize regular workshops",
                "Stop collaborating",
                "Only use email",
                "Work in secret"
            ],
            answer: "Organize regular workshops"
        },
        {
            question: "Aisha is advocating for education. How should she start?",
            options: [
                "Raise awareness via social media",
                "Keep quiet",
                "Only talk to friends",
                "Write a book"
            ],
            answer: "Raise awareness via social media"
        },
        {
            question: "To grow her campaign, what should Aisha do?",
            options: [
                "Work alone",
                "Partner with local governments",
                "Give up",
                "Only use flyers"
            ],
            answer: "Partner with local governments"
        },
        {
            question: "Victor is building an inclusive platform. What should he prioritize?",
            options: [
                "Accessibility for some disabilities",
                "Accessibility for all disabilities",
                "Only for one type of disability",
                "No accessibility"
            ],
            answer: "Accessibility for all disabilities"
        },
        {
            question: "To maintain the platform, what should Victor do?",
            options: [
                "Never update",
                "Ignore feedback",
                "Update platform and get feedback",
                "Only update once"
            ],
            answer: "Update platform and get feedback"
        }
    ];

    let currentQuizQuestionIndex = 0;
    let score = 0;

    const quizContainer = document.getElementById('quiz-container');

    function loadQuizQuestion() {
        if (currentQuizQuestionIndex < quizData.length) {
            const questionData = quizData[currentQuizQuestionIndex];
            quizContainer.innerHTML = `
                <p>${questionData.question}</p>
                <div class="options-container">
                    ${questionData.options.map(option => `<button class="option-button">${option}</button>`).join('')}
                </div>
            `;
            document.querySelectorAll('.option-button').forEach(button => {
                button.addEventListener('click', handleOptionClick);
            });
        } else {
            displayQuizResult();
        }
    }

    function handleOptionClick(event) {
        const selectedOption = event.target.textContent;
        const correctAnswer = quizData[currentQuizQuestionIndex].answer;

        if (selectedOption === correctAnswer) {
            score++;
            event.target.style.backgroundColor = '#8BC34A'; // Green for correct
        } else {
            event.target.style.backgroundColor = '#F44336'; // Red for incorrect
            // Optionally, highlight the correct answer
            Array.from(event.target.parentNode.children).forEach(button => {
                if (button.textContent === correctAnswer) {
                    button.style.backgroundColor = '#8BC34A';
                }
            });
        }

        // Disable all buttons after a choice is made
        document.querySelectorAll('.option-button').forEach(button => {
            button.removeEventListener('click', handleOptionClick);
            button.disabled = true;
        });

        setTimeout(() => {
            currentQuizQuestionIndex++;
            loadQuizQuestion();
        }, 1000); // Move to next question after 1 second
    }

    function displayQuizResult() {
        quizContainer.innerHTML = `
            <p>You scored: ${score}/${quizData.length} Correct</p>
            <button id="play-again-button">Play Again</button>
            <button id="next-level-button">Next Level</button>
        `;
        document.getElementById('play-again-button').addEventListener('click', () => {
            currentQuizQuestionIndex = 0;
            score = 0;
            loadQuizQuestion();
        });
        document.getElementById('next-level-button').addEventListener('click', () => {
            alert('Moving to the next level! (Functionality to be implemented)');
            // Here you would add logic to load content for the next level/SDG
        });
    }

    // Character Scenarios Data (Example for Quality Education - Level 4)
    const characterScenarios = [
        {
            name: "Daniel",
            scenario: "Creating flexible lesson plans for different learning styles.",
            image: "https://via.placeholder.com/100/0000FF/FFFFFF?text=Daniel", // Placeholder URL
            questions: [
                "Q1: First step \u2192 Identify learning styles (correct)",
                "Q2: Long-term support \u2192 Assess and adapt methods (correct)"
            ]
        },
        {
            name: "Leila",
            scenario: "Bridging the tech divide by teaching and providing access.",
            image: "https://via.placeholder.com/100/FF0000/FFFFFF?text=Leila", // Placeholder URL
            questions: [
                "Focus \u2192 Teach basic digital tools",
                "Long-term \u2192 Partner with orgs for devices"
            ]
        },
        {
            name: "Suresh",
            scenario: "Creating a teacher collaboration platform.",
            image: "https://via.placeholder.com/100/00FF00/FFFFFF?text=Suresh", // Placeholder URL
            questions: [
                "First step \u2192 Create resource-sharing platform",
                "Sustainability \u2192 Organize regular workshops"
            ]
        },
        {
            name: "Aisha",
            scenario: "Advocating for underserved communities\u2019 education.",
            image: "https://via.placeholder.com/100/FFFF00/000000?text=Aisha", // Placeholder URL
            questions: [
                "Start \u2192 Raise awareness via social media",
                "Growth \u2192 Partner with local governments"
            ]
        },
        {
            name: "Victor",
            scenario: "Building accessible ed-tech for disabled students.",
            image: "https://via.placeholder.com/100/FF00FF/FFFFFF?text=Victor", // Placeholder URL
            questions: [
                "Prioritize \u2192 Accessibility for all disabilities",
                "Maintain \u2192 Update platform and get feedback"
            ]
        }
    ];

    const scenarioContainer = document.getElementById('scenario-container');

    function loadCharacterScenarios() {
        scenarioContainer.innerHTML = characterScenarios.map(character => `
            <div class="character-card">
                <img src="${character.image}" alt="${character.name}">
                <div class="text-box">
                    <h3>${character.name}'s Scenario</h3>
                    <p>${character.scenario}</p>
                    <ul>
                        ${character.questions.map(q => `<li>${q}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `).join('');
    }

    // Initial load
    loadQuizQuestion();
    loadCharacterScenarios();
});

